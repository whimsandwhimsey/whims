/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: {
      bodySizeLimit: '10mb', // allow larger Excel import uploads
    },
  },
};

export default nextConfig;
