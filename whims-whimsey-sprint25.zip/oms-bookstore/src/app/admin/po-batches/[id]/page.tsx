import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Pencil, Plus } from 'lucide-react';
import { BackButton } from '@/components/back-button';
import { prisma } from '@/lib/prisma';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DeleteButton } from '@/components/delete-button';
import { OrderStatusBadge, PaymentStatusBadge } from '@/components/status-badges';
import { formatCurrency, formatDate, formatMonthYear } from '@/lib/utils';
import { deletePoBatch, togglePoBatchOpen } from '../actions';
import { GenerateInvoicesButton } from '../generate-invoices-button';
import { BatchStatusChanger } from '../batch-status-changer';
import { MultiSelectFilter } from '@/components/multi-select-filter';
import { SortSelect } from '@/components/sort-select';
import { ExportBuilderButton } from '@/components/export-builder-button';
import { BookRowExpandable } from './book-row-expandable';

const TYPE_LABELS: Record<string, string> = {
  PO_REGULAR: 'PO Reguler',
  PO_REMAINDER: 'PO Remainder',
  READY_STOCK: 'Ready Stock',
  EVENT_JASTIP: 'Event / Jastip',
};

const TYPE_RULE: Record<string, string> = {
  PO_REGULAR: 'DP per order, sesuai DP rule masing-masing order',
  PO_REMAINDER: 'DP per order, sesuai DP rule masing-masing order',
  READY_STOCK: 'Full order amount',
  EVENT_JASTIP: 'Full order amount',
};

const PAYMENT_STATUS_LABELS: Record<string, string> = {
  UNPAID: 'Unpaid',
  PARTIAL: 'Partial',
  PAID: 'Paid',
  OVERPAID: 'Overpaid',
};

export default async function PoBatchDetailPage({
  params,
  searchParams,
}: {
  params: { id: string };
  searchParams: { sort?: string; paymentStatus?: string };
}) {
  const batch = await prisma.purchaseBatch.findUnique({
    where: { id: params.id },
    include: {
      supplier: { select: { name: true } },
      orders: {
        include: { customer: true, items: true, invoices: { select: { sentAt: true } } },
        orderBy: { orderDate: 'desc' },
      },
    },
  });
  if (!batch) notFound();

  const bookSummary = new Map<
    string,
    {
      title: string;
      isbn: string | null;
      quantity: number;
      subtotal: number;
      cogs: number;
      buyers: { name: string; phoneLast4: string }[];
    }
  >();
  for (const o of batch.orders) {
    for (const it of o.items) {
      const key = it.isbn || it.bookTitle;
      const existing = bookSummary.get(key);
      const subtotal = Number(it.subtotal.toString());
      const buyer = { name: o.customer.name, phoneLast4: o.customer.phone.slice(-4) };
      if (existing) {
        existing.quantity += it.quantity;
        existing.subtotal += subtotal;
        existing.buyers.push(buyer);
      } else {
        bookSummary.set(key, {
          title: it.bookTitle,
          isbn: it.isbn,
          quantity: it.quantity,
          subtotal,
          cogs: Number(it.cogs.toString()),
          buyers: [buyer],
        });
      }
    }
  }
  const bookRows = [...bookSummary.values()].sort((a, b) => a.title.localeCompare(b.title));
  const totalBookQuantity = bookRows.reduce((sum, r) => sum + r.quantity, 0);

  // Payment / invoice-sent summary for the whole batch.
  const paidCount = batch.orders.filter((o) => o.paymentStatus === 'PAID' || o.paymentStatus === 'OVERPAID').length;
  const unpaidCount = batch.orders.filter((o) => o.paymentStatus === 'UNPAID' || o.paymentStatus === 'PARTIAL').length;
  const sentCount = batch.orders.filter((o) => o.invoices.some((inv) => inv.sentAt)).length;
  const totalOrderValue = batch.orders.reduce((sum, o) => sum + Number(o.totalAmount.toString()), 0);

  const paymentStatuses = (searchParams.paymentStatus ?? '').split(',').filter(Boolean);
  const sort = searchParams.sort === 'name_desc' ? 'name_desc' : searchParams.sort === 'name_asc' ? 'name_asc' : 'recent';

  let displayOrders = batch.orders;
  if (paymentStatuses.length > 0) {
    displayOrders = displayOrders.filter((o) => paymentStatuses.includes(o.paymentStatus));
  }
  displayOrders = [...displayOrders].sort((a, b) => {
    if (sort === 'name_asc') return a.customer.name.localeCompare(b.customer.name);
    if (sort === 'name_desc') return b.customer.name.localeCompare(a.customer.name);
    return b.orderDate.getTime() - a.orderDate.getTime();
  });

  return (
    <div className="p-4 sm:p-6">
      <div className="mb-4 flex items-center justify-between">
        <BackButton label="Back to PO batches" />
        <div className="flex flex-wrap gap-2">
          {batch.isOpen && (
            <Button size="sm" asChild>
              <Link href={`/admin/orders/new?batchId=${batch.id}`}>
                <Plus className="h-4 w-4" /> Add order to this batch
              </Link>
            </Button>
          )}
          <ExportBuilderButton batchId={batch.id} />
          <form action={togglePoBatchOpen.bind(null, batch.id, !batch.isOpen)}>
            <Button
              type="submit"
              variant="outline"
              size="sm"
              className={batch.isOpen ? '' : 'border-success/40 text-success'}
            >
              {batch.isOpen ? 'Close batch' : 'Reopen batch'}
            </Button>
          </form>
          <Button variant="outline" size="sm" asChild>
            <Link href={`/admin/po-batches/${batch.id}/edit`}>
              <Pencil className="h-4 w-4" /> Edit
            </Link>
          </Button>
          <DeleteButton
            action={deletePoBatch.bind(null, batch.id)}
            confirmMessage={`Delete "${batch.name}"? Only possible if no orders are linked.`}
            redirectTo="/admin/po-batches"
          />
        </div>
      </div>

      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-primary">
          {batch.name}
          <span
            className={`ml-2 inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium align-middle ${
              batch.isOpen ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'
            }`}
          >
            {batch.isOpen ? 'Open' : 'Closed'}
          </span>
        </h1>
        <p className="text-sm text-muted-foreground">
          {TYPE_LABELS[batch.type]}
          {batch.supplier ? ` · Supplier: ${batch.supplier.name}` : ' · No supplier set'} · Opened{' '}
          {formatDate(batch.batchDate)}
          {batch.expectedArrivalDate ? ` · Expected ${formatMonthYear(batch.expectedArrivalDate)}` : ''}
        </p>
        <p className="mt-1 text-sm text-brass">Invoice rule: {TYPE_RULE[batch.type]}</p>
        {batch.notes && <p className="mt-2 text-sm text-muted-foreground">{batch.notes}</p>}
      </div>

      <Card className="mb-6">
        <CardContent className="grid grid-cols-2 gap-3 pt-6 sm:grid-cols-4">
          <div>
            <p className="text-xs text-muted-foreground">Total order value</p>
            <p className="text-lg font-semibold">{formatCurrency(totalOrderValue)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Paid</p>
            <p className="text-lg font-semibold text-success">{paidCount}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Unpaid</p>
            <p className="text-lg font-semibold text-destructive">{unpaidCount}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Invoice terkirim</p>
            <p className="text-lg font-semibold">{sentCount}</p>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base">
            Ringkasan buku ({bookRows.length} judul, {totalBookQuantity} eksemplar)
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {bookRows.length === 0 ? (
            <p className="p-4 text-sm text-muted-foreground">Belum ada item.</p>
          ) : (
            <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-2 font-medium">Judul</th>
                  <th className="px-4 py-2 text-right font-medium">Qty</th>
                  <th className="px-4 py-2 text-right font-medium">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {bookRows.map((r, idx) => (
                  <tr key={idx}>
                    <td className="px-4 py-2">
                      <BookRowExpandable title={r.title} buyers={r.buyers} />
                    </td>
                    <td className="px-4 py-2 text-right">{r.quantity}</td>
                    <td className="px-4 py-2 text-right">{formatCurrency(r.subtotal)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base">Bulk invoicing</CardTitle>
        </CardHeader>
        <CardContent>
          <GenerateInvoicesButton
            batchId={batch.id}
            isPoType={batch.type === 'PO_REGULAR' || batch.type === 'PO_REMAINDER'}
          />
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base">Shipping status</CardTitle>
        </CardHeader>
        <CardContent>
          <BatchStatusChanger poBatchId={batch.id} orderCount={batch.orders.length} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Orders in this batch ({batch.orders.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {batch.orders.length > 0 && (
            <div className="flex flex-wrap gap-2 border-b border-border p-4">
              <MultiSelectFilter
                paramKey="paymentStatus"
                label="Payment"
                options={Object.entries(PAYMENT_STATUS_LABELS).map(([value, label]) => ({ value, label }))}
              />
              <SortSelect
                defaultValue="recent"
                options={[
                  { value: 'recent', label: 'Terbaru dulu' },
                  { value: 'name_asc', label: 'Customer (A-Z)' },
                  { value: 'name_desc', label: 'Customer (Z-A)' },
                ]}
              />
            </div>
          )}
          {batch.orders.length === 0 ? (
            <p className="p-6 text-sm text-muted-foreground">
              No orders assigned to this batch yet — pick it from the &quot;PO Batch&quot; field when creating
              or editing an order.
            </p>
          ) : displayOrders.length === 0 ? (
            <p className="p-6 text-sm text-muted-foreground">No orders match this filter.</p>
          ) : (
            <ul className="divide-y divide-border">
              {displayOrders.map((o) => (
                <li key={o.id}>
                  <Link
                    href={`/admin/orders/${o.id}`}
                    className="flex flex-col gap-2 p-4 hover:bg-secondary/50 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div>
                      <p className="font-medium">{o.customer.name}</p>
                      <p className="text-xs text-muted-foreground">{o.orderNumber}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <PaymentStatusBadge status={o.paymentStatus} />
                      <OrderStatusBadge status={o.status} />
                      <span className="w-24 text-right font-medium">
                        {formatCurrency(o.totalAmount.toString())}
                      </span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
