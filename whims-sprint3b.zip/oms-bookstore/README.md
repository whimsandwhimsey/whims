# Slow Reads — Bookstore Order Management System

A production-oriented OMS for a pre-order bookstore: customers, orders, book
line-items, payments (QRIS / Bank Transfer), customer deposits, invoices
(print / image / WhatsApp), and financial reporting — with a separate
admin/staff console and a customer self-service portal.

**Stack:** Next.js 14 (App Router, full-stack) · TypeScript · Prisma ·
PostgreSQL · NextAuth · Tailwind CSS + shadcn/ui-style components.

---

## Build status: Milestone 5 of 5 — all milestones complete 🎉

This project was delivered incrementally, as requested. Each milestone was
fully working end-to-end before the next one started.

| # | Milestone | Status |
|---|---|---|
| 1 | Project scaffold, full DB schema, dual authentication (staff + customer) | ✅ Done |
| 2 | Customer & order management (CRUD, book items, auto-calculated totals, search/filter/pagination) | ✅ Done |
| 3 | Payments & deposits (QRIS/Bank Transfer, overpay → deposit, deposit history) | ✅ Done |
| 4 | Invoices (print/image/WhatsApp) + Excel import/export | ✅ Done |
| 5 | Dashboard & financial reports (charts, revenue, receivables, exports) + audit log UI | ✅ Done (this delivery) |

A good number of extra features (rebrand, customer self-signup, PO
batches, packing list, expenses, self-service top-up/address requests,
account settings, and more) were also added along the way based on
real-world feedback — see the "Added:" sections below for each.

Everything in **General Requirements** that is structural (database design,
audit log table, project architecture) is already in place, since later
milestones build directly on top of it rather than reshaping it.

---

## Added: searchable dropdowns, fixed book formats, catalog simplification, multi-filter orders, portal dashboard reorder

- **Searchable dropdowns** (`src/components/searchable-select.tsx`) replace
  plain `<select>` everywhere the list can grow long: Customer, PO Batch,
  and Book pickers on the order form, and the "Related order" picker on
  the expense form. Type to filter, click to pick.
- **Book format is now a fixed choice** — Paperback / Hardcover / Boxset
  (`BookFormat` enum) — on both the Book catalog and each order item,
  instead of free text.
- **Book catalog no longer stores price or COGS** — only title, author,
  ISBN, and format. Selling price and COGS are always entered fresh per
  order item (they can legitimately differ between POs for the same
  title), never auto-filled from the catalog anymore.
- **COGS is back on the order form**, but purely as reporting input — it
  doesn't show anywhere on the order detail page, only rolls up into the
  new COGS / Gross Profit figures on `/admin/reports`.
- **Orders list**: added a PO Batch column, and the Status/Payment/PO
  Batch filters are now checkbox multi-selects (e.g. PO Batch A **and**
  Payment status Unpaid, at the same time) instead of one-at-a-time
  dropdowns.
- **Customer portal dashboard reordered**: profile (name/phone/address) →
  outstanding balance & deposit balance side by side → a filterable,
  item-level order table (book, PO batch, price, qty, payment status,
  searchable by title) → Top up deposit → **Upcoming bookmail** (renamed
  from "What am I waiting for?") → FAQ.

---

## Added: quick-add customer from order form, WhatsApp on approval, real QRIS

- **Quick-add customer from the order form** — the Customer picker now has
  a "+ Add new customer" option at the top. Picking it opens a small inline
  form (name, phone, address); submitting creates the customer (as
  ACTIVE — no approval step, since staff is entering them directly) and
  selects them immediately, no need to leave the order to visit
  `/admin/customers` first.
- **WhatsApp confirmation on signup approval** — the Approve button on
  `/admin/customers` now also opens WhatsApp with a ready-to-send "you're
  confirmed, go check your orders" message to the customer, right after
  approving. Reject is unchanged (no message needed there).
- **Real QRIS image is in** (`public/qris.png`) — the customer top-up page
  now shows the actual Slow Reads QRIS code instead of the placeholder.

---

## Rebrand + customer self-signup (added after Milestone 3)

- **Visual identity** now uses the real "Slow Reads" logo (`public/logo.png`)
  throughout — homepage, both login pages, admin sidebar — with a sage-green
  / warm-white palette and a bold rounded display font (Baloo 2) matching
  the logo's lettering. Color tokens live in `src/app/globals.css`.
- **Homepage** now puts the customer login front and center (large card,
  primary button) with a small, deliberately understated "Staff login" text
  link — matching how most traffic to this app is customers, not staff.
- **Customer self-signup** (`/signup`, public, no login required): a
  customer submits name, phone, and address. This creates a `Customer` row
  with `status: PENDING` — they cannot log in yet. Staff approve or reject
  from the Customers list (a banner surfaces the pending count; Approve/
  Reject buttons appear inline for pending rows). Only `ACTIVE` customers
  can sign in to the portal; the login page shows one deliberately generic
  message for "not found" and "still pending" so a stranger probing phone
  numbers can't distinguish the two cases.

---

## What's included in Milestone 3

- **Record payments** (QRIS or Bank Transfer) against any order directly
  from the order detail page. The order's `amountPaid`, `outstandingBalance`,
  and `paymentStatus` all recalculate automatically.
- **Automatic overpay → deposit**: if a payment is larger than what's still
  owed on the order, the extra amount is capped off the order (which never
  shows more than "Paid") and the remainder is recorded as a `TOP_UP`
  deposit transaction for that customer — exactly as described in the
  brief.
- **Deposit top-ups not tied to an order**: from a customer's profile page,
  staff can record a payment that becomes pure deposit (e.g. a customer
  pre-paying before they've placed an order).
- **Apply deposit to an order**: from the order detail page, staff can
  apply some or all of a customer's deposit balance toward that order's
  outstanding balance — recorded as a `USED` transaction.
- **Deposit refunds**: staff can refund some or all of a customer's
  deposit back to them, recorded as a `REFUND` transaction.
- **Customer profile page** (`/admin/customers/:id`): deposit balance,
  full deposit transaction history, and that customer's order list, all
  in one place.
- **Payments overview** (`/admin/payments`): every payment ever recorded,
  searchable by customer or order number.
- **Customer portal**: the deposit balance card is now real (not a
  placeholder), linking to a full, transparent deposit transaction history
  page — matching the brief's requirement that deposit history be fully
  visible to the customer.
- The deposit balance is never a single stored number — it's always
  derived from the `DepositTransaction` ledger (each row stores its own
  `balanceAfter`), so the running balance and full history can never drift
  out of sync with each other.

## What's included in Milestone 4

- **Invoices** for all three types from the brief — Deposit, Final Payment,
  Ready Stock — created from the order detail page with sensible amount
  defaults per type (editable before saving). Every invoice gets a unique
  number (`INV-2026-000001`, etc.).
- **Printable invoice page** (`/admin/invoices/:id` for staff,
  `/portal/invoices/:id` for the customer, ownership-checked) — a clean,
  mobile-first document that works identically on-screen, printed
  (`window.print()` → "Save as PDF" from the browser's own print dialog),
  or exported as an image.
- **Send via WhatsApp (text)**: one tap opens WhatsApp with a pre-filled,
  formatted message (invoice number, items, totals) addressed to the
  customer's own phone number — no copy-pasting needed.
- **Share/export as image**: on phones that support the Web Share API,
  "Share as image" hands a captured PNG of the invoice straight to
  WhatsApp's (or any app's) native share sheet — genuinely one tap from
  invoice to WhatsApp message with the image attached. Falls back to a
  plain "Download as image" button everywhere else.
- **Invoices list** (`/admin/invoices`) — searchable by invoice #, order #,
  or customer, with a mobile card layout below the `sm` breakpoint and a
  full table above it.
- **Excel export** for Customers, Books, Orders, and Payments
  (`/api/export/...`, staff-only).
- **Excel import for Customers** — upload an `.xlsx` with Name/Phone/
  Address/Notes columns (matching the export format, so export → edit →
  re-import round-trips cleanly); reports how many rows were created vs.
  skipped, with reasons.
- Every new screen in this milestone was built mobile-first: buttons stack
  and go full-width below `sm`, tables collapse to cards where it matters,
  and the invoice document itself is a fixed, phone-friendly width rather
  than stretching full-bleed.

## Added after Milestone 4: payments editing, PO batches, expenses, packing list

- **Edit & delete payments** (`/admin/payments/:id/edit`, plus inline "Edit"
  links on the order detail page and the Payments list). Editing or
  deleting a payment fully replays that order's payment history afterward
  (`lib/order-recalc.ts`) so `amountPaid`/`outstandingBalance`/
  `paymentStatus` and any deposit top-up it generated stay correct no
  matter where in the history the edit happened — never patched
  incrementally, always recomputed from scratch.
- **PO Batches** (`/admin/po-batches`): named, typed batches — **Fast PO**
  (4–8 weeks), **PO Reg** (4–5 months), or **Ready Stock** — that orders
  can be optionally assigned to. Each type carries its own invoicing rule:
  Fast PO → 50% deposit, PO Reg → Rp 50,000 per book ordered, Ready Stock →
  full amount. A batch's detail page has a **"Generate invoices for all
  orders in this batch"** button that applies the rule to every order in
  one click; the same rule also prefills the amount when creating a single
  invoice from an order that belongs to a batch.
- **COGS removed from the order screens** — no more COGS input per book or
  Profit/COGS shown on the order detail page. Profit is no longer tracked
  per order; see Expenses below for the replacement.
- **Expenses** (`/admin/expenses`): record packing materials, shipping to
  the warehouse, or other operational costs, optionally tied to a specific
  order. The dashboard now shows Revenue collected, Total expenses, and
  **Net profit** (revenue − expenses) as a company-wide figure instead of
  a per-book-COGS calculation.
- **Packing List** (`/admin/packing`): every order with at least one
  payment recorded (and not yet Completed/Cancelled), queued in the order
  payments came in — first paid, first packed, so nothing gets skipped.
  Each row has a courier picker (Lion / Ojek / Shopee) and a tracking
  number field; saving marks the order Shipped automatically. Customers
  see the courier and tracking number on their own order page as soon as
  it's saved.

## Added: customer self-service (top-up, address change, pre-order overview)

- **Inline deposit top-up** on the admin Customers list — record a top-up
  for any customer without opening their profile page.
- **Customer portal profile card**: name, phone, and address always visible
  at the top of the dashboard, with an "Update address" shortcut.
- **"What am I waiting for?"** (`/portal/pre-orders`): every book the
  customer has ordered, grouped by PO batch, with outstanding balance
  broken down by batch, by expected-arrival month, and as a grand total.
- **Self-service deposit top-up** (`/portal/topup`): customer scans a QRIS
  code (drop your real one at `public/qris.png` — falls back to a friendly
  placeholder until then), enters the amount they sent, and taps one
  button that (1) logs a pending top-up request and (2) opens WhatsApp
  with a ready-to-send message to the store's number so they can attach
  their transfer receipt. Nothing hits the deposit ledger until staff
  confirms it from **Admin → Requests**.
- **Self-service address change** (`/portal/profile/edit-address`):
  customer submits a new address; it only overwrites `Customer.address`
  once staff confirms it from **Admin → Requests** — same
  confirm/reject pattern as the top-up requests and the original signup
  approval flow.
- Update the admin's WhatsApp number in
  `src/app/portal/topup/page.tsx` (`ADMIN_WHATSAPP` constant) if it ever
  changes.
- **Full order history with search/filter** (`/portal/orders`) — the
  dashboard now shows the 5 most recent orders with a link through to this
  page for everything else.
- **Packing queue position**: any order with a payment recorded (and not
  yet shipped) shows "#X of Y" on its detail page, from the same
  first-paid-first-packed ordering the admin Packing List uses
  (`src/lib/packing-queue.ts`, shared by both).
- **FAQ page** (`/portal/faq`): static answers for the most common
  questions (how top-up works, what order statuses mean, how invoices
  read, etc.) so customers have somewhere to look before messaging
  WhatsApp.

## Added: staff account settings (change password)

- **`/admin/account`**: any signed-in staff/admin can change their own
  password (requires entering the current one first). Linked from
  "Account" next to the sign-out button in the sidebar/top bar.
- **Do this before going live**: sign in as `admin` and `staff1` and change
  both passwords away from the seeded defaults (`Admin123!` /
  `Staff123!`) — those are public in this README.

## Added: real delete for books/customers, ISBN + format, batch-driven arrival

- **Books can now always be deleted** — order items already keep their own
  title/price/COGS snapshot, and the DB relation is `onDelete: SetNull`, so
  removing a book from the catalog never touches order history.
- **Customers with order history are archived instead of deleted** when
  you hit delete — this keeps every order/payment/deposit record intact
  (deleting the customer outright would either orphan or destroy that
  history). Archived customers disappear from the default list and can't
  log in to the portal; filter by "Archived" to find them again. A
  customer with **zero** orders is still deleted outright, same as before.
- **ISBN + Format** on both the Book catalog and each order line item —
  shown as a small subtitle under the title on order pages (admin and
  customer) rather than extra columns, to stay mobile-friendly.
- **Custom books typed directly into an order are now saved to the
  catalog automatically** — matched first by ISBN, then by exact title, to
  avoid duplicates; only created fresh if nothing matches. The order form
  shows a small note when this will happen.
- **Expected arrival now comes from the PO Batch**, not typed per order:
  picking a batch on the order form fills in (and locks) the arrival date
  from that batch. Editing a batch's arrival date cascades to every order
  in it automatically. Orders with no batch (e.g. a one-off Ready Stock
  sale) still take a manual date as before.

---

## Added: Milestone 5 (financial reports + audit log) + order delete fix

- **`/admin/reports`**: revenue vs. expenses vs. net profit as a combo
  chart, a deposit activity chart (top-ups / used / refunds), a monthly
  breakdown table, and snapshot cards (outstanding receivables, deposits
  currently held, all-time revenue/expenses) — all for the last 12
  months, with an Excel export.
- **`/admin/audit-log`**: browse every recorded mutation (search by
  entity/summary, filter by action type, paginated). The data has existed
  since Milestone 2; this is the browsing UI for it.
- **Orders can now always be "deleted"** — same philosophy as the
  customer/book fix above: if an order has no payments, invoices, deposit
  usage, or expenses tied to it, it's removed outright. If it does, hitting
  delete **cancels** it instead (status → Cancelled) so the financial trail
  stays intact — it disappears from every active view either way. A
  delete button was also added to the Orders list itself (previously only
  on the order detail page).

---

## Deploying for free (Vercel + Neon)

This is the cheapest realistic path to production: **Vercel** (hosting,
free Hobby plan) + **Neon** (managed Postgres, free tier that doesn't
expire). Both are genuinely free for a small bookstore's traffic, not
time-limited trials.

### 1. Push the code to GitHub

Vercel deploys straight from a Git repo, so create a repo and push this
project there first.

### 2. Create a free Neon database

1. Sign up at [neon.tech](https://neon.tech) → **New Project**.
2. In the project dashboard, copy **both** connection strings:
   - **Pooled connection** (has `-pooler` in the hostname) → this is your `DATABASE_URL`.
   - **Direct connection** (no `-pooler`) → this is your `DIRECT_URL`.
   - Make sure the pooled one includes `?sslmode=require&pgbouncer=true` at the end (Neon usually adds this for you).

### 3. Import the project into Vercel

1. [vercel.com](https://vercel.com) → **Add New Project** → import your GitHub repo.
2. Framework preset: Next.js (auto-detected).
3. Under **Environment Variables**, add:
   | Key | Value |
   |---|---|
   | `DATABASE_URL` | Neon pooled connection string |
   | `DIRECT_URL` | Neon direct connection string |
   | `NEXTAUTH_SECRET` | output of `openssl rand -base64 32` |
   | `NEXTAUTH_URL` | your Vercel URL, e.g. `https://your-app.vercel.app` (update after first deploy if the URL changes) |
4. Under **Build & Development Settings**, set the **Build Command** to:
   ```
   npx prisma migrate deploy && npm run build
   ```
   (this applies your schema to Neon automatically on every deploy).
5. Click **Deploy**.

### 4. Seed the database once

**With a computer (has Node.js):**
```bash
# locally, with .env pointing at the same DATABASE_URL/DIRECT_URL as Neon
npm run db:seed
```

**Without a computer / from an iPad:** open your Neon project → **SQL
Editor** tab → paste in the contents of `prisma/seed.sql` → Run. It
contains the same sample admin/staff/customer/order data with
pre-computed password hashes, so nothing needs to run locally at all.

### Doing this entire deployment from an iPad (no laptop)

Every step above is browser-based except getting the code onto GitHub in
the first place (normally a `git push` from a terminal). Here's the
laptop-free version of that one step:

1. Unzip the project — iPad's **Files** app extracts `.zip` files natively
   (tap the file).
2. Install **Working Copy** (free, App Store) — a Git client for iPad.
   The free tier allows unlimited pushes to **one** repository, which is
   all this project needs.
3. In Working Copy: create a new repository, import the unzipped project
   folder into it, sign in to GitHub (built-in), and push to a new GitHub
   repo.
4. Continue from "Import the project into Vercel" above — that and the
   Neon setup are pure Safari/browser steps.
5. Seed via the Neon SQL Editor as described just above.

### Done

Visit your `*.vercel.app` URL — both `/login/admin` and `/login/customer`
should work against the live Neon database.

---

**Free-tier limits to know about:**
- Neon free tier: ~0.5 GB storage and the database auto-suspends after
  inactivity (it wakes up automatically on the next request, with a
  short cold-start delay — fine for a small bookstore's traffic).
- Vercel Hobby plan: fine for this use case, but is licensed for
  non-commercial/personal use per Vercel's terms — worth reading
  [Vercel's pricing page](https://vercel.com/pricing) once this is a real
  paid business, and upgrading to a paid plan if needed.
- File uploads/generated PDFs: Vercel's filesystem is temporary per
  request, so once we build PDF invoice generation (Milestone 4) it will
  need to write to a storage bucket (e.g. Vercel Blob, which also has a
  free tier) instead of local disk — noted for that milestone.

### Free alternative if you outgrow Neon/Vercel later

Same Docker Compose setup from the section above works unmodified on any
VPS (a small DigitalOcean/Contabo box, ~$5/mo) if you want full control
instead of managed free tiers — nothing in the code needs to change,
just the `DATABASE_URL`/`DIRECT_URL` values.

---

## Getting started (local, without Docker)

**Prerequisites:** Node.js ≥ 18.18, npm, and a PostgreSQL 14+ instance
(local install, or use the Docker Compose `db` service below and just skip
the `app` service).

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env: set DATABASE_URL to your Postgres instance, and generate a
# NEXTAUTH_SECRET with:
openssl rand -base64 32

# 3. Create the database schema
npx prisma migrate dev --name init

# 4. Seed sample data (admin/staff/customer/sample order)
npm run db:seed

# 5. Run the dev server
npm run dev
```

Visit `http://localhost:3000`.

**Seeded logins (see console output after seeding, or below):**

| Type | Identifier | Password |
|---|---|---|
| Admin | `admin` | `Admin123!` |
| Staff | `staff1` | `Staff123!` |
| Customer | phone `081234567890` | *(no password — phone only)* |

⚠️ Change or remove these before deploying anywhere real.

---

## Getting started (Docker Compose)

```bash
cp .env.example .env
# set a real NEXTAUTH_SECRET in .env

docker compose up --build
```

This starts Postgres and the app, runs `prisma migrate deploy`
automatically on container start, and serves the app on
`http://localhost:3000`. Run the seed once the containers are up:

```bash
docker compose exec app npm run db:seed
```

---

## Project structure

```
prisma/
  schema.prisma        # full data model for the whole system
  seed.ts               # sample data
src/
  app/
    page.tsx            # landing page — choose staff or customer login
    login/admin/         # staff username+password login
    login/customer/      # customer phone-number login
    admin/                # staff-only area (protected by middleware)
    portal/               # customer-only area (protected by middleware)
    api/auth/[...nextauth]/route.ts
    globals.css           # design tokens (CSS variables) for the theme
  components/
    ui/                   # shadcn-style primitives (Button, Input, Card, Label)
    book-spines.tsx        # shared decorative motif for auth screens
    providers.tsx           # NextAuth SessionProvider wrapper
    sign-out-button.tsx
  lib/
    auth.ts               # NextAuth config — both credential providers live here
    prisma.ts              # Prisma client singleton
    session.ts              # getAuthSession() server helper
    utils.ts                 # cn(), formatCurrency(), formatDate(), normalizePhone()
  middleware.ts            # protects /admin/* and /portal/* by account type
  types/next-auth.d.ts      # session/user type augmentation
```

---

## Architecture notes

- **Why Next.js full-stack:** one deployable app, one language, Server
  Components for data-heavy admin screens, Route Handlers/Server Actions
  for mutations — appropriate for a single bookstore's back office. If this
  ever needs to scale into a separate mobile app or third-party
  integrations, the same Prisma schema and business logic can be lifted
  behind a dedicated API layer without a rewrite.
- **Snapshotted order items:** `OrderItem` copies `bookTitle`/price/COGS at
  the time of order rather than only referencing `Book`, so editing the
  catalog later never rewrites historical orders or profit reports.
- **Denormalized order totals:** `Order.totalAmount`, `.profit`,
  `.amountPaid`, `.outstandingBalance`, `.paymentStatus` are stored
  columns, recalculated by server-side logic whenever items/payments
  change (built in Milestone 2/3) — this keeps dashboard and report
  queries fast without recomputing aggregates on every read.
- **Deposits as a ledger, not a single balance field:** a customer's
  deposit balance is always the sum of their `DepositTransaction` rows
  (`TOP_UP`, `USED`, `REFUND`, `ADJUSTMENT`), each storing
  `balanceAfter` — so the full history requested for the customer portal
  is a first-class, auditable table rather than a derived guess.
- **Audit log:** a generic `AuditLog` table (actor, action, entity type/id,
  before/after JSON) is in the schema now; write calls will be added
  alongside each mutation as those features are built.

## Security notes

- Customer login currently only checks that the phone number exists —
  there is no OTP yet, matching the brief ("OTP can be added later").
  To upgrade later: add an `otp_codes` table (phone, code, expiresAt,
  consumedAt), send a code via an SMS/WhatsApp provider, and verify it in
  the `authorize()` callback of the `customer-login` provider in
  `src/lib/auth.ts` before returning the user — the session shape and
  middleware do not need to change.
- Passwords are hashed with bcrypt; never store plaintext.
- Set a strong, unique `NEXTAUTH_SECRET` per environment.

## What's next (optional ideas, not required)

All 5 milestones are done and this is ready for real use (after you
change the seeded default passwords — see "Account settings" above).
Some ideas if you want to keep extending it later:

- Automatic WhatsApp status-change notifications to customers.
- A short in-portal onboarding/FAQ walkthrough for first-time customers.
- Shipping label printing (reusing the same print/image-export pattern as
  invoices).
- Customer tags/notes for quick reference (e.g. "VIP", "often late to pay").
